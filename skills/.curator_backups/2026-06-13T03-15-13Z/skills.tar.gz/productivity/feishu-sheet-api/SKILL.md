---
name: feishu-sheet-api
description: "Read, write, and style Feishu (Lark) spreadsheets via the REST API — authentication, sheet metadata, value CRUD, cell formatting, and batch operations"
version: 1.0.0
author: agent
metadata:
  hermes:
    tags: [feishu, sheets, api, spreadsheet, automation]
    related_skills: [voice-pipeline, hermes-agent]
---

# Feishu Sheet API

Read, write, and format Feishu (飞书) spreadsheets programmatically using the tenant_access_token flow. Covers authentication, sheet structure discovery, value CRUD, handling dropdown/select cells (`#UNSUPPORT VALUE`), and cell style application.

## Architecture

```
Feishu App (cli_xxx) → tenant_access_token → Sheets API
  ├── GET  /sheets/v3/spreadsheets/{token}/sheets/query   → sheet list + metadata
  ├── GET  /sheets/v2/spreadsheets/{token}/values/{range} → read cell values
  ├── PUT  /sheets/v2/spreadsheets/{token}/values          → write cell values
  └── PUT  /sheets/v2/spreadsheets/{token}/style           → apply cell formatting
```

## Authentication

```python
import requests

app_id = "cli_xxx"  # from .env: FEISHU_APP_ID
app_secret = "xxx"  # from .env: FEISHU_APP_SECRET

resp = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal", 
    json={"app_id": app_id, "app_secret": app_secret})
token = resp.json()["tenant_access_token"]
headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
```

Token expires in ~2 hours (check `expire` field in response). Generate a fresh one for each session.

## Required Permissions

Add these in the Feishu Developer Console → app → Permissions → Sheets:

| Scope | Level | What it enables |
|-------|-------|-----------------|
| `sheets:spreadsheet:readonly` | Read | Query sheet metadata, read cell values |
| `sheets:spreadsheet` | Read+Write | Write cell values, apply styles |

**After adding permissions:** must create a new app version and publish, then re-authorize at:
`https://open.feishu.cn/app/{app_id}/auth`

For Drive folder listing, additionally need `drive:drive:readonly` (requires admin approval for many tenants).

### Determine the actual data range first (critical!)

Sheets often have 456K+ total rows but only ~10K with actual data. Reading the full sheet (e.g., `B:F` for all rows) will read hundreds of thousands of empty rows and timeout. **Always find the data range first:**

```python
# Read only column A — fast even for large sheets
r = requests.get(f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{sheet_token}/values/{sheet_id}!A:A', headers=headers)
vals = r.json()['data']['valueRange']['values']
header = vals[0]  # row 1
total_rows = len(vals) - 1  # minus header
rows_with_data = sum(1 for v in vals[1:] if v and v[0])

print(f'Sheet has {total_rows} total rows, {rows_with_data} with data')
# Now read only the data range: A{1}:I{rows_with_data+1}
```

This avoids timeouts and unnecessary API costs when the sheet has thousands of empty trailing rows.

### List sheets in a spreadsheet

```python
sheet_token = "Qmf2s..."  # from URL: /sheets/{token}

resp = requests.get(
    f"https://open.feishu.cn/open-apis/sheets/v3/spreadsheets/{sheet_token}/sheets/query",
    headers=headers
)
data = resp.json()
for s in data["data"]["sheets"]:
    print(s["sheet_id"], s["title"], s["grid_properties"]["row_count"])
```

### Get spreadsheet metadata (owner, title)

```python
resp = requests.get(
    f"https://open.feishu.cn/open-apis/sheets/v3/spreadsheets/{sheet_token}",
    headers=headers
)
meta = resp.json()["data"]["spreadsheet"]
# → { "owner_id": "ou_...", "title": "...", "token": "...", "url": "..." }
```

## Reading Values

### Read a rectangular range

```python
resp = requests.get(
    f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{sheet_token}/values/0fUaAr!A1:T6",
    headers=headers
)
data = resp.json()
if data["code"] == 0:
    values = data["data"]["valueRange"]["values"]
    for row in values:
        print(row)
```

Range format: `{sheet_id}!{col}{start_row}:{col}{end_row}`

### Handling dropdown / select cells

Cells with data validation dropdowns or combo boxes return `{"type": "#UNSUPPORT VALUE"}` from the simple values API. These are **dict objects**, not plain strings. Always check with `isinstance(val, dict)` before processing.

```python
def clean(val):
    if val is None or isinstance(val, dict):
        return ""
    return str(val)

```python
def prepare_for_write(val):
    if isinstance(val, dict):
        return ""       # ⚠️ Do NOT use "#N/A" — Feishu interprets that as error formula
    return val if val is not None else ""
```

## Writing Values

### Write a full range (all rows, all columns)

```python
BATCH = 4000
full = [header] + data_rows
for start in range(0, len(full), BATCH):
    end = min(start + BATCH, len(full))
    batch = full[start:end]
    resp = requests.put(
        f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{sheet_token}/values",
        headers=headers,
        json={"valueRange": {
            "range": f"1iPmja!A{start+1}:I{end}",
            "values": batch
        }}
    )
    d = resp.json()
    if d["code"] != 0:
        print(f"Write failed: {d.get('msg')}")
```

**Critical rules:**
- All values in the matrix must be plain strings, numbers, or `None` — no dict objects (they cause "invalid cell type").
- Range must cover EVERY row including unchanged ones (no gaps). Use full slices, not just changed cells.
- Max ~5000 cells per batch; 4000 rows with 9 columns = 36K cells — split.
- Sheet ID in range (`1iPmja`) is NOT the same as the display name (`Sheet1`). Use the ID from sheet list query.

### Alternative: write only changed columns

If you only need to update columns B, C, E, F (not the full range):

```python
# Group by column and write contiguous runs
col_data = {"B": [], "C": [], "E": [], "F": []}
# ... populate with (row_num, value) tuples sorted by row ...

for col, items in col_data.items():
    if not items:
        continue
    ranges = []  # (start_row, end_row, values_matrix)
    run = [items[0]]
    for item in items[1:]:
        if item[0] == run[-1][0] + 1:
            run.append(item)
        else:
            ranges.append((run[0][0], run[-1][0], [[v] for _, v in run]))
            run = [item]
    ranges.append((run[0][0], run[-1][0], [[v] for _, v in run]))
    
    for start_row, end_row, vals in ranges:
        resp = requests.put(
            f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{sheet_token}/values",
            headers=headers,
            json={"valueRange": {
                "range": f"1iPmja!{col}{start_row}:{col}{end_row}",
                "values": vals
            }}
        )
```

## Cell Styling

### ⚠️ Critical ordering rule: `PUT /values` clears all cell styles

Writing cell values via `PUT /values` **resets the formatting** of every cell in the written range. Any previously-applied `foregroundColor` or `backgroundColor` is lost.

**Always apply styles AFTER all data writes are complete.** Never apply styles first, then write data — the write will wipe them.

If you must do multiple write-and-style cycles, re-apply styles after every batch write.

### ⚠️ KNOWN BUG (confirmed in production): `foregroundColor` returns code=0 but is NOT visible

**CONFIRMED: `foregroundColor` does NOT work.** Multiple production sessions, including visual verification by the user (color filter in Feishu UI shows only black), confirm that `appendStyle` with `foregroundColor` **silently succeeds** (returns code=0) but produces **zero visible effect**. The API accepts the request, the sheet revision increments, but cells remain black — the font color never changes.

**ALWAYS use `backgroundColor` (background fill) instead.** Background color changes ARE visible and reliable. Do NOT use `foregroundColor` for any purpose where the user needs to see the result. If you find yourself thinking "maybe it works this time" — it doesn't.

### RGB Color Values

Feishu uses **0.0–1.0 float** range for RGB, **not** 0–255 integers:
```python
# ✅ Correct (0-1 floats)
purple_font = {'foregroundColor': {'red': 0.5, 'green': 0.0, 'blue': 0.8}}
purple_bg = {"red": 0.86, "green": 0.78, "blue": 1.0}

# ❌ Wrong — Feishu will silently ignore or fail
purple_bad = {'foregroundColor': {'red': 128, 'green': 0, 'blue': 204}}
```

### ⚠️ Chinese placeholder patterns: "待设置" / "待定" / "无"

Chinese data sheets commonly use placeholder strings that LOOK like real data but mean "missing". Common ones:
- `待设置` = "to be set" (most common)
- `待定` = "TBD"
- `无` = "none" (ambiguous — may be real value or missing)
- `N/A`, `null`, `暂无` = "none yet"

**These are NOT UNSUPPORT VALUE dicts** — they come back as plain strings, so simple `isinstance(v, dict)` checks miss them. You need an explicit list:

```python
PLACEHOLDERS = {'待设置', '待定', 'N/A', 'null', '暂无'}

def is_real_value(val, placeholders=PLACEHOLDERS):
    if val is None or isinstance(val, dict):
        return False
    s = str(val).strip()
    if not s:
        return False
    if s in placeholders:
        return False
    return True
```

When filling from reference tables, treat placeholders the same as empty cells — try to overwrite with real values. Workflow:
1. Read target sheet
2. For each row, check both empty AND placeholder conditions against mappings
3. If mapping has a real value, write it (overwriting the placeholder)
4. After write, count remaining placeholders — this is your "still missing" number to report

Counting pattern for "待设置" specifically:
```python
# After write, count remaining "待设置" cells
r = requests.get(f'{base}/values/{sheet_id}!C:C', headers=headers)
admins = r.json()['data']['valueRange']['values'][1:]
dsz = sum(1 for v in admins if v and v[0] and "待设置" in v[0])
empty = sum(1 for v in admins if not v or not v[0])
real = sum(1 for v in admins if v and v[0] and "待设置" not in v[0])
print(f'待设置={dsz}, 空={empty}, 有真名={real}')
# Report: '新填了 X 个 (从 4784 减到 4781)'
```

Cells of type `{"type": "#UNSUPPORT VALUE"}` (dropdown/select error cells) **do not render** either `foregroundColor` or `backgroundColor` changes, even though the style API returns code=0.

**Workflow:**
1. Read the data columns
2. Replace ALL dict/UNSUPPORT VALUE cells with empty string `""` (NOT `"#N/A"`)
3. Write the clean data back via `PUT /values`
4. Apply styles to the now-clean ranges

Skip steps 1-3 if the cells are already plain strings/empty (not dict type).

### Apply background color (recommended over font color)

```python
purple_bg = {"red": 0.86, "green": 0.78, "blue": 1.0}

# Split into ~2000-row chunks (larger ranges fail with 90202)
col = 'B'
for start in range(2, 10345, 2000):
    end = min(start + 1999, 10344)
    rs = f'1iPmja!{col}{start}:{col}{end}'
    resp = requests.put(
        f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{sheet_token}/style',
        headers=headers,
        json={'appendStyle': {'range': rs, 'style': {'backgroundColor': purple_bg}}}
    )
```

### ❌ Apply font color — DO NOT USE (confirmed broken)

Despite returning code=0, `foregroundColor` has zero visible effect. Use `backgroundColor` above instead.

**Confirmed broken even after cleaning cells:** Writing empty strings to replace UNSUPPORT VALUE dicts, then applying `foregroundColor` to the clean range, still produces no visible color. The user verified via Feishu UI color filter — only black appears. This is a Feishu API limitation, not a data-cleaning issue.

This section is preserved only for reference. Do not use in production.

```python
purple_font = {'foregroundColor': {'red': 0.5, 'green': 0.0, 'blue': 0.8}}

for start in range(2, 10345, 2000):
    end = min(start + 1999, 10344)
    rs = f'1iPmja!{col}{start}:{col}{end}'
    resp = requests.put(
        f'https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{sheet_token}/style',
        headers=headers,
        json={'appendStyle': {'range': rs, 'style': purple_font}}
    )
```

**DO NOT USE `foregroundColor` — it is a confirmed silent no-op.** The API returns `code=0` but the font color never changes visually. Verified by multiple production sessions including user-side visual confirmation via Feishu UI color filter.

**Range format:** Always use start:end format even for single cells — `"B6:B6"` works but `"B6"` alone fails with 90202.

**Speed tip:** Apply styling to the largest contiguous range per column rather than individual cells. The API is fast for large ranges, slow for thousands of individual calls.

## Common Errors

| Code | Meaning | Fix |
|------|---------|-----|
| 91403 | Forbidden — missing scope | Add `sheets:spreadsheet` permission, publish, re-authorize |
| 90202 | Invalid range | Use `"B6:B6"` format, not `"B6"` for single cells. Also: ranges over ~2000 rows per call fail — split into chunks of 2000 rows or fewer |
| 9499 | Missing `appendStyle` wrapper | Wrap in `{"appendStyle": {"range": ..., "style": ...}}` |
| 99991672 | Missing scope violation | Visit auth URL to grant the required scope |

## 🔴 MANDATORY: Self-Verify Before Reporting

**User requirement (recorded):** "做事情做了一定先自己检查，做完汇报" — After every write operation, you MUST verify the results yourself before telling the user anything. Never ask "好了吗" or "怎么样" without first reading back sample cells and confirming the data was written correctly.

**This is the single most important rule in this skill.** The user has explicitly corrected this behavior. If you report without verifying, you will be corrected again. Verification is not optional — it is the first thing you do after any write, before any message to the user.

**Verification checklist (run ALL of these before reporting):**
1. Read back a cell that should have been filled — confirm the expected value is there
2. Read back a cell that should be empty — confirm it's empty (not dict/UNSUPPORT VALUE)
3. Count filled cells per column — confirm the count matches expectations
4. Only after ALL checks pass, report the confirmed result to the user

```python
# MANDATORY verification after every write
# 1. Check a filled cell
r = requests.get(f'{base}/values/{sheet_id}!B6:B6', headers=headers)
actual = r.json()['data']['valueRange']['values'][0][0]
assert isinstance(actual, str) and actual not in ('', '#N/A'), f'Write failed: {actual}'

# 2. Check an empty cell
r = requests.get(f'{base}/values/{sheet_id}!B100:B100', headers=headers)
actual = r.json()['data']['valueRange']['values'][0][0]
assert actual == '', f'Expected empty, got {actual}'

# 3. Count filled cells
r = requests.get(f'{base}/values/{sheet_id}!B:B', headers=headers)
vals = r.json()['data']['valueRange']['values'][1:]
filled = sum(1 for v in vals if v and isinstance(v[0], str) and v[0].strip())
print(f'Column B: {filled} filled cells')

# 4. Now report to user
```

**Do NOT skip this step.** The user has explicitly flagged this as a priority. If you report without verifying, you will be corrected.

## Data Enrichment Pattern: Cross-Sheet IP Lookup

### Target sheet shapes:
- **SourceIP/DestIP format** (firewall log): columns A=SourceIP, B=用途, C=管理员, D=DestinationIP, E=用途, F=管理员, G/H/I=Protocol/Port/Policy. Build separate `src_map` and `dst_map` from reference data.
- **Single-IP format** (IP database): columns A=IP, B=用途, C=管理员. Build a flat `ip_map` from reference data. Simpler — one mapping applies to all rows. Often has placeholder "待设置" markers to overwrite (see Chinese placeholder patterns above).

### IP Database Sync: Append new IPs from reference table

When syncing an IP database from a firewall log table:

1. **Build mapping** from the firewall log — extract ALL unique SourceIPs and DestinationIPs with their purpose/admin
2. **Read existing IP database** — collect all existing IPs into a set
3. **Find new IPs** — any IP in the mapping not in the existing set is new
4. **Append** new rows to the bottom of the database
5. **Fill gaps** — for existing rows with "待设置" or empty admin, overwrite from mapping
6. **Style** — apply purple background to newly added rows and filled cells

**Pitfall:** The `needs_fill` check must be applied to BOTH purpose AND admin columns independently. A common bug is checking only purpose and assuming admin has the same status — they often differ (purpose filled, admin "待设置").

A common workflow: fill `#N/A` cells in a target sheet by looking up IP addresses in reference sheets that have IP→purpose/admin mappings.

**Target sheet shapes:**
- **SourceIP/DestIP format** (firewall log): columns A=SourceIP, B=用途, C=管理员, D=DestinationIP, E=用途, F=管理员, G/H/I=Protocol/Port/Policy. Build separate `src_map` and `dst_map` from reference data.
- **Single-IP format** (IP database): columns A=IP, B=用途, C=管理员. Build a flat `ip_map` from reference data. Simpler — one mapping applies to all rows. Often has placeholder "待设置" markers to overwrite (see Chinese placeholder patterns above).

**Steps:**
1. Build mapping dicts from all reference sheets: `src_map[ip] = [purpose, admin]`
2. Read target sheet data
3. For each row, check if SourceIP/DestinationIP is in the mapping
4. Only fill cells that are `#N/A` or `#UNSUPPORT VALUE` (don't overwrite existing data)
5. Write back the entire sheet in batches
6. **Apply styles LAST** — `PUT /values` clears any previously-applied cell formatting
7. **🔴 SELF-VERIFY BEFORE REPORTING (MANDATORY):** Read back a sample of cells to confirm values were written correctly. Check a known-good cell, a known-fill cell, and column totals. Do NOT ask the user "好了吗" or "怎么样" — verify first, then report the confirmed result.

**Verification (🔴 MANDATORY — do NOT report without confirming):**
```python
# After writing, always read back a sample to verify the data was written correctly
# Check cells that should have been filled AND cells that should remain empty
sample_target = requests.get(f'{base}/values/1iPmja!B6:B6', headers=headers)
actual_target = sample_target.json()['data']['valueRange']['values'][0][0]
assert actual_target == '用户电脑', f'Expected "用户电脑", got {actual_target}'

sample_untouched = requests.get(f'{base}/values/1iPmja!B100:B100', headers=headers)
actual_untouched = sample_untouched.json()['data']['valueRange']['values'][0][0]
# Should be empty string '' not dict/UNSUPPORT — confirms cleanup worked

# Verify column counts match expectations
r = requests.get(f'{base}/values/1iPmja!B:B', headers=headers)
vals = r.json()['data']['valueRange']['values'][1:]
text_count = sum(1 for v in vals if v and isinstance(v[0], str) and v[0].strip())
print(f'{text_count} cells with text content in column B')

# Only report results AFTER confirmation. Do NOT ask "好了吗" — verify first, then report.
```

## Reference: See `references/ip-lookup-cross-sheet.md` for a full annotated script, including the **bidirectional round-trip** pattern (fill target from IP DB, then reverse-fill IP DB with new IPs discovered in target).

Scripts: `scripts/verify-write.py` — standalone post-write verification helper.

### ⚠️ "Zero Intersection" Problem in Reverse-Fill

When reverse-filling an IP database from a reference table (e.g., filling IP DB admin column from a firewall log), a common outcome is **zero matches** — the IPs that need filling (marked "待设置" or empty) simply don't exist in the reference table's IP set. This is not a bug; it means the data sources are disjoint.

**Don't exhaustively scan every reference table hoping for a match.** Before starting the fill, do a quick intersection check:

```python
# Quick intersection check before full fill
db_ips_needing_fill = {ip for ip, (p, a) in db_map.items() if needs_fill(a)}
ref_ips = set(ref_map.keys())
overlap = db_ips_needing_fill & ref_ips
print(f'DB IPs needing admin: {len(db_ips_needing_fill)}')
print(f'Reference IPs: {len(ref_ips)}')
print(f'Intersection: {len(overlap)}')
if len(overlap) == 0:
    print('Zero intersection — no point scanning further tables')
```

This check takes seconds and saves minutes of unnecessary API calls and data processing. Report the zero-intersection finding to the user and ask if they have another data source, rather than silently scanning every available table.

### execute_code blocked for cron jobs

The `execute_code` tool is blocked in cron job sessions (security restriction — cron runs without user present). For scheduled sheet operations, use `write_file` + `terminal` pattern instead:
1. Write the Python script to `/tmp/` with `write_file`
2. Execute it with `terminal(command="python3 /tmp/script.py", timeout=300)`

## Pitfalls

- **Read vs Write permissions are separate scopes.** `sheets:spreadsheet:readonly` does NOT enable writes. You need the full `sheets:spreadsheet` scope.
- **Publishing is not enough — re-authorize.** After adding scopes, you must create a new app version, publish it, AND visit the auth URL to re-consent.
- **NEVER write the string `"#N/A"` to clear a cell.** Feishu interprets the literal string `"#N/A"` as the `#N/A` error formula type, which gets stored as `{"type": "#UNSUPPORT VALUE"}`. Write empty string `""` instead.
- **UNSUPPORT VALUE cells do not render style changes.** If you apply `foregroundColor` or `backgroundColor` to a range that includes UNSUPPORT VALUE cells, the style API succeeds (code=0) but the cells won't visibly show the color change. You MUST first write empty strings `""` to those cells to convert them to plain empty cells, then apply styles.
- **`foregroundColor` is a confirmed silent no-op — even after cleaning cells.** Despite returning code=0, font color never changes visually. Verified by user-side visual confirmation (Feishu UI color filter shows only black). Always use `backgroundColor` instead.
- **`PUT /values` clears ALL cell styles.** Writing cell values resets formatting of every cell in the written range. Always apply styles AFTER all data writes are complete.
- **Verify before reporting — always.** Read back a sample of cells after writing. Check a filled cell, an empty cell, and the total count. Never ask "好了吗" without verifying first.
- **Sheet ID ≠ sheet name.** `Sheet1` is the display name; the API uses IDs like `0fUaAr`. Always get the ID from the sheet list query.
- **Token expiry is ~2 hours.** For long operations, re-generate the token periodically.
- **Rate limiting:** Stay under ~5 requests/second. Add `time.sleep(0.3)` between batch writes.
- **Large ranges fail the style API.** Ranges over ~2000 rows (e.g., `B2:B10344`) fail with code 90202 "validate RangeVal fail". Split into chunks: rows 2-2000, 2002-4000, etc.
- **Read only the data range, not the full sheet.** A sheet may have 456K+ total rows but only 10K with actual data. Always determine the data range first (e.g., by checking column A for non-empty cells).
